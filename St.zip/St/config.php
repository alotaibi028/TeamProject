<?php
set_time_limit(0);



$con = mysqli_connect('localhost','root','7606MA','project_team_system');

	if(!$con){
		echo "not connected";
		}
		else "connected";
	
		

?>
